/* Arvydas Kapacinskas IF-2/1 arvkap */
/* Failas: arvkap_readdir01.c */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>

int vp_test();

int vp_test(){
   return 0;
}

int main( int argc, char * argv[] ){
   DIR *dir;
   struct dirent *ent;
   printf( "(C) 2013 Arvydas Kapacinskas, %s\n", __FILE__ );
   
   if((dir = opendir(".")) != NULL){
	   while((ent = readdir(dir)) != NULL){ 
			printf("Failo pavadinimas: %s, i-node: %ld \n", ent->d_name, ent->d_ino);
	   }
	   closedir(dir);
   }
   return 0;
}